package com.example.thymeleafdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan({ "com.example.thymeleafdemo.*" })
public class SpringBootThymeleftApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootThymeleftApplication.class, args);
	}

}
